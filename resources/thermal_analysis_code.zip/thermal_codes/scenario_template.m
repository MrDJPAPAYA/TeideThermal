%{
# Thermal scenario set up function.

OUTPUT:

This function returns a structure with 

* initial temperature of each node
* internal dissipation of each node
* solar irradiation on each node
* albedo irradiation on each node
* planetary IR irradiation on each node

All units are SI units.

This function can be used as a template when creating new scenarios.

Mario Merino <mario.merino@uc3m.es>, 2020
%}
function scenario = scenario_template

%% Scenario name, description, date
scenario.info.name = 'LAB_THR'; % name
scenario.info.date = '20200421'; % date
scenario.info.description = 'LABTHR1?EQ'; % description

%% Nodes 
scenario.nodes.n = 6; % Number of nodes. Must be consistent with the following

%% Initial condition
scenario.ic = ... % Initial condition for the temperature of each node [K]
[
    120
	120
	120
	120
    120
    120
];

%% Internal dissipation
scenario.Qi = ... % Power dissipated in each node [W]
[
    5
	7
	12
	10
    40
    4
];

%% Solar irradiation

scenario.Qsun = ... % This is the heat load to each node due to solar irradiation [W] and already includes the surface area
1366* ...           % 1366 W/m2 is the solar irradiance
[
    0.2^2           % 0.2 m is the panel side
    0.2^2
    0
	0
	0.2^2
	0.2^2
];

scenario.Qsun_phase = ... % Solar irradiation phase angle [rad].
[
   -pi
    0
    0
	0
	3*pi/2.
	pi/2.
];

%% Albedo irradiation
scenario.Qalbedo = ... % Solar irradiation [W]
0.3*1366*0.1* ...
[
    0
    0
    0
	0
	0
	0
];

%% planetary IR irradiation
scenario.Qplanetary = ... % Solar irradiation [W]
237*(6371/8000)^2* ...
[
    0
    0
    0
	0
	0
	0
];