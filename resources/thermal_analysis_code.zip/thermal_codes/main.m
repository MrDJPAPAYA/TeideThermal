%% This is the main of the thermal simulation
%addpath('E:\UC3M\MISE_Spacecraft_design\Curso_2020-2021')
mu = 398600;
r  = 6378.0 + 36000.0;
T  = 2.*pi*sqrt(r^3/mu);
n = 2*pi/T;   % Not used

%n = 7.3E-5;   % This does not depend on the orbit in this case, but on the 
              % rotation of the Sun with respect to the Earth

model = model_template;
scenario = scenario_template;
tspan = [0.0, 5*T];
options = odeset('AbsTol',1e-8,'RelTol',1e-8);
[t,T] = integrator(model,n,scenario,tspan,options);

% Qsun for all nodes

Qsun1 = zeros(length(t),1);
for i = 1: length(t)
    Qsun_angle = scenario.Qsun_phase(1) + n * t(i);
    angle_aux = n*t(i) - 2*pi * floor(n*t(i)/(2*pi));
    theta_max = pi + 0.15;
    theta_min = pi - 0.15;
    if angle_aux < theta_max && angle_aux > theta_min
        Qsun1(i) = 0.0;
    else
        if sin(Qsun_angle) < 0.0
            Qsun1(i) = 0.0;
        else
            Qsun1(i) = model.radiation.Asun(1) .*(sin(Qsun_angle)*scenario.Qsun(1));
        end
    end
end

Qsun5 = zeros(length(t),1);
for i = 1: length(t)
    Qsun_angle = scenario.Qsun_phase(5) + n * t(i);
    angle_aux = n*t(i) - 2*pi * floor(n*t(i)/(2*pi));
    theta_max = pi + 0.15;
    theta_min = pi - 0.15;
    if angle_aux < theta_max && angle_aux > theta_min
        Qsun5(i) = 0.0;
    else
        if sin(Qsun_angle) < 0.0
            Qsun5(i) = 0.0;
        else
            Qsun5(i) = model.radiation.Asun(5) .*(sin(Qsun_angle)*scenario.Qsun(5));
        end
    end
end

figure(10);
plot(t, Qsun1, 'k');
hold on;
plot(t, Qsun5, 'r');
xlabel ('Hours since the start of the simulation','Fontsize',24);
ylabel ('Heat load from the Sun on node 1 and 5 [W]','Fontsize',24);
set(gca,'Fontsize',24);

figure(1);
plot(t, T(:,1), 'k');
hold on;
plot(t, T(:,2), 'y');
hold on;
plot(t, T(:,3), 'm');
hold on;
plot(t, T(:,4), 'b');
hold on;
plot(t, T(:,5), 'r');
hold on;
plot(t, T(:,6), 'g');
xlabel ('Elapsed simulation time [s]','Fontsize',24);
ylabel ('Temperature of the different nodes [K]','Fontsize',24);
set(gca,'Fontsize',24);
